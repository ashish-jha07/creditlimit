import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mastermanagement',
  templateUrl: './mastermanagement.component.html',
  styleUrls: ['./mastermanagement.component.scss']
})
export class MastermanagementComponent implements OnInit {

  constructor() { 
    
  }

  ngOnInit(): void {
  }

}
