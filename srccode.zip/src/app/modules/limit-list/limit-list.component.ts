import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-limit-list',
  templateUrl: './limit-list.component.html',
  styleUrls: ['./limit-list.component.scss']
})
export class LimitListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
